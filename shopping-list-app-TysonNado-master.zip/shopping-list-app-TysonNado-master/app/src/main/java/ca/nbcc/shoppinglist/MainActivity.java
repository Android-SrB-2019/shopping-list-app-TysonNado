package ca.nbcc.shoppinglist;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity {

    public static final int TEXT_REQUEST = 1;

    private TextView garlic_output,shwarma_output,apple_output,friedchicken_output,orange_output;
    private TextView banana_output,pepper_output,lettuce_output,milk_output,pepperoni_output;

    public static final String GARLIC = "garlic";
    public static final String SHWARMA = "shwarma";
    public static final String APPLE = "apple";
    public static final String FRIEDCHICKEN  = "friedchicken";
    public static final String ORANGE = "orange";
    public static final String BANANA = "banana";
    public static final String PEPPER = "pepper";
    public static final String LETTUCE = "lettuce";
    public static final String MILK = "milk";
    public static final String PEPPERONI = "pepperoni";
    private TextView output;

    private int garlic=0,shwarma=0,apple=0,friedchicken=0,orange=0;
    private int banana = 0,pepper=0,lettuce=0,milk=0,pepperoni=0;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        garlic_output = (TextView)findViewById(R.id.garlic_output);
        milk_output = (TextView)findViewById(R.id.milk_output);
        shwarma_output = (TextView)findViewById(R.id.shwarma_output);
        apple_output = (TextView)findViewById(R.id.apple_output);
        friedchicken_output  = (TextView)findViewById(R.id.friedChicken_output);
        orange_output = (TextView)findViewById(R.id.orange_output);
        banana_output = (TextView)findViewById(R.id.banana_output);
        pepper_output = (TextView)findViewById(R.id.pepper_output);
        lettuce_output = (TextView)findViewById(R.id.letuce_output);
        pepperoni_output = (TextView)findViewById(R.id.peperoni_output);
        output = (TextView)findViewById(R.id.output);


        if (savedInstanceState != null)
        {
            garlic = savedInstanceState.getInt(GARLIC);
            shwarma = savedInstanceState.getInt(SHWARMA);
            apple = savedInstanceState.getInt(APPLE);
            friedchicken = savedInstanceState.getInt(FRIEDCHICKEN);
            orange = savedInstanceState.getInt(ORANGE);
            banana = savedInstanceState.getInt(BANANA);
            pepper = savedInstanceState.getInt(PEPPER);
            lettuce = savedInstanceState.getInt(LETTUCE);
            milk = savedInstanceState.getInt(MILK);
            pepperoni = savedInstanceState.getInt(PEPPERONI);
        }
        setOutputText();
    }
    public void setOutputText()
    {
        garlic_output.setText("Garlic: " + garlic);
        shwarma_output.setText("Shwarma:  " + shwarma);
        apple_output.setText("Apple: " + apple);
        friedchicken_output.setText("6pc/ Fried Chicken: " + friedchicken);
        orange_output.setText("Orange: " + orange);
        banana_output.setText("Banana " + banana);
        pepper_output.setText("Pepper: " + pepper);
        lettuce_output.setText("Lettuce: " + lettuce);
        pepperoni_output.setText("Pepperoni: " + pepperoni);
        milk_output.setText("Milk: " + milk);
    }

    public void launchSecondActivity(View view) {
        Intent intent = new Intent(this, SecondActivity.class);
        startActivityForResult(intent,TEXT_REQUEST);
    }

    @Override
    public void onActivityResult(int requestCode,int resultCode, Intent data)
    {
        super.onActivityResult(requestCode,resultCode,data);
        if (requestCode == TEXT_REQUEST)
        {
            String listitem = data.getStringExtra(SecondActivity.EXTRA_REPLY);
            if(resultCode == RESULT_OK)
            {
                switch (listitem)
                {
                    case GARLIC:
                        garlic+=1;break;
                    case SHWARMA:
                        shwarma+=1;break;
                    case APPLE:
                        apple+=1;break;
                    case FRIEDCHICKEN:
                        friedchicken+=1;
                        break;
                    case BANANA:
                        banana+=1;
                        break;
                    case PEPPER:
                        pepper+=1;
                        break;
                    case LETTUCE:
                        lettuce+=1;
                        break;
                    case MILK:
                        milk+=1;
                        break;
                    case PEPPERONI:
                        pepperoni+=1;
                        break;
                    case ORANGE:
                        orange+=1;
                        break;
                    default: break;
             }
                setOutputText();
            }
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState){
        super.onSaveInstanceState(outState);
        outState.putInt(GARLIC,garlic);
        outState.putInt(SHWARMA,shwarma);
        outState.putInt(APPLE,apple);
        outState.putInt(FRIEDCHICKEN,friedchicken);
        outState.putInt(ORANGE,orange);
        outState.putInt(BANANA,banana);
        outState.putInt(PEPPER,pepper);
        outState.putInt(LETTUCE,lettuce);
        outState.putInt(MILK,milk);
        outState.putInt(PEPPERONI,pepperoni);





    }
}
