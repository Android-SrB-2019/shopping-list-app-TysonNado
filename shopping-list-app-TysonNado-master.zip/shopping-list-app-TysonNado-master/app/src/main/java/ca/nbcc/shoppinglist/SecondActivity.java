package ca.nbcc.shoppinglist;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
public class SecondActivity extends AppCompatActivity {

    public static final String EXTRA_REPLY = "ca.nbcc.shoppinglist.extra.REPLY";

    private TextView output;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.choose_listitem);
        output = (TextView)findViewById(R.id.output);
    }

    public void finish(String data)
    {
        Intent x = new Intent();
        x.putExtra(EXTRA_REPLY,data);
        setResult(RESULT_OK,x);
        finish();
    }

    public void addGarlicToList(View view) {
        finish(MainActivity.GARLIC);
    }
    public void addAppleToList(View view) {
        finish(MainActivity.APPLE);
    }
    public void addBananaToList(View view) {
        finish(MainActivity.BANANA);
    }

    public void addFriedChickenToList(View view) {
        finish(MainActivity.FRIEDCHICKEN);
    }

    public void addLettuceToList(View view) {
        finish(MainActivity.LETTUCE);
    }

    public void addMilkToList(View view) {
        finish(MainActivity.MILK);
    }

    public void addOrangeToList(View view) {
        finish(MainActivity.ORANGE);
    }

    public void addPepperToList(View view) {
        finish(MainActivity.PEPPER);
    }

    public void addShwarmaToList(View view) {
        finish(MainActivity.SHWARMA);
    }
    public void addPepperoniToList(View view) {
        finish(MainActivity.PEPPERONI);
    }


}
