package ca.nbcc.shoppinglist;

public class Items {
}
